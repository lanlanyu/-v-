<?php
	$index = $_GET['index'];
	"select * from `{$index}` where" 
?>